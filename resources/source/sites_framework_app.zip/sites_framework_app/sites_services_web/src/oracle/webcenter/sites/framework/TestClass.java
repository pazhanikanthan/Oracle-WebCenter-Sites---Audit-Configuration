package oracle.webcenter.sites.framework;


public class TestClass {

    public static void main(String[] args) {
        /*
        int totalRecordCount = 126;
        int rpp = 25;
        int pnum = 5;
        int startRowNum = 0; 
        int endRowNum = 0;
        
        if (totalRecordCount > 0) {
            int pageCount = totalRecordCount / rpp;
            if ((totalRecordCount % rpp) != 0) {
                pageCount++;
            }
            for (int i = 1; i <= pageCount; i++) {
                System.out.println ("Page " + i);
            }
        }
        
        if (totalRecordCount > 0) {
            startRowNum = (pnum * rpp) - (rpp) + 1;
            endRowNum = (pnum * rpp);
            if (totalRecordCount < endRowNum) {
                endRowNum = totalRecordCount;
            }
        }
        System.out.println ("startRowNum: " + startRowNum);
        System.out.println ("endRowNum: " + endRowNum);
        */
        
    }
}
